<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/34a70120-8d56-4b92-8244-e63457ab0fc5

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Android app packaging

This package includes the full React console inside the Android WebView shell. The previous Android activity was only the default “Hello Android” screen; it has been replaced so the app opens the actual Sovereign Trust OS modules.

### Modules included
- RC3 Hardening Console
- API Explorer
- Zendit API modules: Wallet, Top Up, eSIM, Gift Cards, MSISDN Lookup, Transactions, Promotions, Reports
- Giftbit API modules: System/Ping, Brands, Email Orders, Shortlinks, Direct Links, Embedded Rewards, Funds, Rewards Management
- Digital Receipt / Claim Preview
- Execution Logs
- API Reference Guide

### Live backend
The packaged app runs in Simulator mode without a backend. For Testbed or Production, open the globe icon in the app header and enter the Cloud Run/API gateway URL. The URL is stored locally on the device and the frontend sends requests to that backend.
